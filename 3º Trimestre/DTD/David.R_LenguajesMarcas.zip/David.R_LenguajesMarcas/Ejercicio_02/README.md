# Ejercicio 02 - Jugadores de Baloncesto en XML

Este ejercicio representa jugadores de una liga de baloncesto usando XML y una DTD externa.

## Estructura del XML
Cada `<jugador>` contiene:
- Nombre
- Apellidos
- Equipo (ciudad y presidente)
- Edad

La DTD externa valida esta estructura.
