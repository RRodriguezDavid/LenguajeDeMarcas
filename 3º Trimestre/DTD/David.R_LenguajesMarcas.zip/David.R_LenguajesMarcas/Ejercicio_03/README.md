# Ejercicio 03 - Agenda Personal en XML

Este ejercicio valida una agenda personal con una DTD externa.

## Estructura del XML
La `<agenda>` contiene:
- Nombre y múltiples apellidos
- Teléfono
- Fecha de nacimiento (año, mes, día)
- Lugar de nacimiento (país, ciudad, localidad)
