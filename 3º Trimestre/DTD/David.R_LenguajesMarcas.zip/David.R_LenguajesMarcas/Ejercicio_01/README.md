# Ejercicio 01 - Biblioteca en XML

Este ejercicio representa una colección de libros usando XML. Se incluye una DTD interna para validar la estructura.

## Estructura del XML
Cada `<libro>` contiene:
- Título
- Editorial
- Autor (Nombre y Apellidos)
- Número de páginas

Se incluyen tres libros de ejemplo.
