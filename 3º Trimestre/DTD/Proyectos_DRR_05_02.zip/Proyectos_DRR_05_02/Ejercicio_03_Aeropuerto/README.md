# Ejercicio 3 - Aeropuerto

Documento XML y DTD para representar información de vuelos en un aeropuerto, incluyendo código, estado y si es diario.