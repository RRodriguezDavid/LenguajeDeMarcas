# Ejercicio 2 - Equipos NBA

Documento XML con DTD para representar equipos de la NBA con títulos, posición y quinteto titular.