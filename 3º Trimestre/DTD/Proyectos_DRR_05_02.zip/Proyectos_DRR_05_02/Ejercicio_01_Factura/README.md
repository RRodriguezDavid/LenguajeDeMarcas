# Ejercicio 1 - Factura electrónica

Este ejercicio representa una factura XML con validación DTD para una transacción entre una librería y una biblioteca.