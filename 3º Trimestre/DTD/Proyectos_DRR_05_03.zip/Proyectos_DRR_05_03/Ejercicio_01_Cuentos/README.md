# Ejercicio 1 - Cuentos

Este ejercicio incluye dos cuentos en formato XML y un archivo DTD para validación.

## Requisitos no expresables en DTD
- El patrón de codificación del atributo `cod` (una letra seguida de dos números).
- El formato numérico exacto del precio (dos dígitos, dos decimales).
