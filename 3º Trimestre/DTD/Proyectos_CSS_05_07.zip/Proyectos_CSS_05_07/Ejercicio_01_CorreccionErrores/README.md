# Ejercicio 1 - Corrección de Errores XML

Este ejercicio contiene cuatro documentos XML corregidos. Cada uno fue revisado para cumplir con su DTD interna correspondiente. Ahora son válidos y pueden ser verificados con un validador de XML.
